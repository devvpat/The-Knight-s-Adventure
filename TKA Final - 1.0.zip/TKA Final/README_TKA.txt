Created by:
*Dev Patel

General Info:
*Version 1.0

Controls:
*Tutorial in-game, but here is a brief overview:
**A to move left
**D to move right
**Space to jump
**Esc to toggle pause
**R to restart level
**M to return to menu
